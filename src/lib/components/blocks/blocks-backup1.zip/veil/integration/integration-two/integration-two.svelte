<script>
	import { Button } from "$lib/components/ui/veil-ui/button";
	import ChevronRight from "@lucide/svelte/icons/chevron-right";
	import IntegrationIllustration from "./integration-illustration.svelte";
</script>

<section data-theme="veil" class="@container bg-background py-24">
	<div class="mx-auto max-w-2xl">
		<IntegrationIllustration />
		<div class="text-centent mx-auto mt-12 max-w-md px-6">
			<h2 class="font-serif text-4xl font-medium">Connect Your Favorite Tools</h2>
			<p class="mt-4 mb-6 text-muted-foreground">
				Seamlessly integrate with the services you already use. Set up in minutes, not days.
			</p>
			<Button variant="secondary" size="sm" class="gap-1 pr-1.5">
				Learn more
				<ChevronRight />
			</Button>
		</div>
	</div>
</section>
